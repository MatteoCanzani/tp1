<?php

trait PuedoRecolectar {
    public function recolectar(Recolectable $objeto) {
        $tiempo = ceil($objeto->getAlimento() / $this->velocidadRecoleccion());
        echo "Recolecté todo el alimento en $tiempo minutos." . PHP_EOL;
    }
}
