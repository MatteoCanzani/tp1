<?php

class AldeanoChino extends Aldeano {
    public function __construct() {
        $this->setBonus(0); 
    }
}

