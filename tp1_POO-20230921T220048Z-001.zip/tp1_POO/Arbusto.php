<?php

require_once 'Recolectable.php';
class Arbusto extends Alimento implements Recolectable {
    private $cantidadAlimento;

    public function __construct() {
        $this->cantidadAlimento = 125; 
    }

    public function getAlimento(): int {
        return $this->cantidadAlimento;
    }
}

