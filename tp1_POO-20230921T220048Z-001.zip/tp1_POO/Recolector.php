<?php
interface Recolector {
    public function recolectar(Recolectable $objeto);
}