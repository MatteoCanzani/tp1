<?php
require_once 'Unidad.php';
require_once 'Alimento.php';
require_once 'Arbusto.php';
require_once 'BancoDePesca.php';
require_once 'Pesquero.php'; 
require_once 'Recolector.php';
require_once 'Recolectable.php';
require_once 'PuedoRecolectar.php';
require_once 'TengoComida.php';
require_once 'Aldeano.php';
require_once 'AldeanoChino.php';
require_once 'AldeanoFranco.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de la recolección</title>
</head>
<body>
    <h1>Resultados de la recolección</h1>

    <?php
   
    $aldeano = new AldeanoChino; 
    $arbusto = new Arbusto;

    echo'el aldeano va a recolectar :';
    echo"<br>";
   
   

    echo $aldeano->recolectar($arbusto) . "<br>";
    echo"<br>";

    $pesquero = new Pesquero; 
    $bancoDePesca = new BancoDePesca;

    echo'el Pesquero va a recolectar :';
    
    echo"<br>";

    echo $pesquero->recolectar($bancoDePesca) . "<br>";
    echo"<br>";
    //tarda mas por el banco de pesca :)


    $aldeanoChino = new AldeanoChino;
    $aldeanoFranco = new AldeanoFranco;
    $arbusto1 = new Arbusto;
    $arbusto2 = new Arbusto;

    echo'el aldeanoChino va a recolectar :';
    echo"<br>";
    
    echo $aldeanoChino->recolectar($arbusto1) . "<br>";
    echo"<br>";

    echo'el aldeanoFranco va a recolectar :';
    echo"<br>";
    echo $aldeanoFranco->recolectar($arbusto2) . "<br>";
    ?>

</body>
</html>
