<?php

class BancoDePesca extends Alimento implements Recolectable {
    public function __construct() {
        parent::__construct(225); 
    }

    public function getAlimento(): int {
        return parent::getAlimento(); 
    }
}

