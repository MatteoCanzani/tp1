<?php

abstract class Unidad {
    abstract public function recolectar(Recolectable $objeto);
    abstract public function bonus(): int;
    abstract public function velocidadRecoleccion(): int;
}
