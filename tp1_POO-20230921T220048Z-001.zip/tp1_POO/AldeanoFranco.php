<?php

class AldeanoFranco extends Aldeano {
    public function __construct() {
        $this->setBonus(25); 
    }
}

