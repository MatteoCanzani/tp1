<?php
//mecanismo de reutilización de código en leguajes que tienen herencia simple
trait TengoComida {
    private $cantidadAlimento;

    public function __construct() {
        $this->cantidadAlimento = $this->calcularAlimento();
    }

    public function getAlimento(): int {
        return $this->cantidadAlimento;
    }

    abstract protected function calcularAlimento(): int;
}