<?php
//permiten crear código con el cual especificar qué métodos deben ser implementados por una clase, sin tener que definir cómo estos métodos son manipulados.
interface Recolectable {
    public function getAlimento(): int;
}