<?php

class Alimento {
    private $cantidadAlimento;

    public function __construct($cantidad) {
        $this->cantidadAlimento = $cantidad;
    }

    public function getAlimento() {
        return $this->cantidadAlimento;
    }
}