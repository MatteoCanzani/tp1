<?php

require_once 'Recolector.php';
require_once 'PuedoRecolectar.php'; 

class Pesquero extends Unidad implements Recolector {
    use PuedoRecolectar; 
    private $bonus = 0;

    public function setBonus($bonus) {
        $this->bonus = $bonus;
    }

    public function bonus(): int {
        return $this->bonus;
    }

    public function velocidadRecoleccion(): int {
        return ceil(18 * (1 + ($this->bonus / 100)));
    }
}
